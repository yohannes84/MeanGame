
const { moduleHasNonRelativeName } = require("typescript");
const gamesData = require("../api/data/games.json")
const schoolData = require("../api/data/school.json")

module.exports.getAll = function(req,res){
    console.log("Get all Games");
    res.status(200).json(gamesData);

}
module.exports.getOne = function(req,res){
    
    const gamedID =  req.params.gamedID;
    const theGame = gamesData[gamedID];
    console.log("Getting one game only by gameID: ", gamedID);
    res.status(200).send(theGame);
}

module.exports.getAllstudents = function(req,res){
    console.log("Getting all the students");
    res.status(200).json(schoolData)
}

module.exports.getOneStudent = function(req,res){
    
    const stdID = req.params.stdID
    const stdInfo = schoolData[stdID]
    console.log("getting one student by ID ", stdID);
    res.status(200).json(stdInfo)
}